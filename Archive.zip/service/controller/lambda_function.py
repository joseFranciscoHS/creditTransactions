from ..service.create_summary import read_sqs

def lambda_handler(event, context):
    read_sqs(**event)