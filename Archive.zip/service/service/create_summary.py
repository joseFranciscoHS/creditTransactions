from service.model.decorators import LOGGER
from ..model.transactions import Transaction
from ..config.config import Config
from ..model.database import Dynamo

cfg = Config()
SQS = cfg.get_boto_client('sqs')
LOGGER = cfg.get_logger()

def delete_sqs(arn: str):
    SQS.delete_message(arn)

def new_summary(filename: str):
    trns = Transaction()
    df = trns.read_transactions(filename)
    summary = trns.create_summary(df)
    return summary

def new_db_record(summary: dict):
    db = Dynamo()
    db.store_summary(summary)

def read_sqs(**event):
    for record in event['Records']:
        try:
            summary = new_summary(record['Body'])
            new_db_record(summary)
            delete_sqs(record['eventSourceARN'])
        except Exception as e:
            LOGGER.warning(e)
